package model;

public class UsuarioNoExiste extends Exception{

	public UsuarioNoExiste() {
		// TODO Auto-generated constructor stub
		super("El usuario no existe");
	}

}
